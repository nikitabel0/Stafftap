from fastapi import APIRouter, UploadFile, File, HTTPException
import uuid
import shutil

router = APIRouter(prefix="/api/upload", tags=["upload"])


@router.post("/avatar")
def upload_avatar(file: UploadFile = File(...)):
    if file.content_type not in ["image/jpeg", "image/png"]:
        raise HTTPException(status_code=400, detail="Only jpg/png allowed")

    filename = f"{uuid.uuid4()}.jpg"
    path = f"static/avatars/{filename}"
    with open(path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    url = f"https://your-storage.com/avatars/{filename}"
    return {"url": url}
