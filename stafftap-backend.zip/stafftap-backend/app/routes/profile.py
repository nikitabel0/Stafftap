from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.responses import JSONResponse

from app.dependencies import get_current_user
from app.database import get_db
from app.models.user import User
from app.models.review import Review
from app.schemas.profile import (
    ProfileUpdate,
    EmployeeProfile,
    EmployerProfile,
    ReviewOut
)

router = APIRouter(prefix="/api/profile", tags=["profile"])


@router.get("", response_model=EmployeeProfile | EmployerProfile)
def get_profile(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    user = current_user

    # Получаем отзывы (последние 5)
    reviews = (
        db.query(Review)
        .filter(Review.target_id == user.id)
        .order_by(Review.created_at.desc())
        .limit(5)
        .all()
    )
    review_list = [
        ReviewOut(
            id=rev.id,
            reviewer_id=rev.reviewer_id,
            target_id=rev.target_id,
            rating=rev.rating,
            comment=rev.comment,
            created_at=rev.created_at
        )
        for rev in reviews
    ]

    base_data = {
        "id": user.id,
        "role": user.role,
        "phone": user.phone,
        "email": user.email,
        "is_verified": user.is_verified,
        "is_blocked": user.is_blocked,
        "created_at": user.created_at,
        "updated_at": user.updated_at,
        "reviews": review_list
    }

    if user.role == "worker":
        return EmployeeProfile(
            **base_data,
            first_name=user.first_name,
            last_name=user.last_name,
            experience_months=user.experience_months,
            rate_per_shift=float(user.rate_per_shift or 0)
        )
    else:
        return EmployerProfile(
            **base_data,
            first_name=user.first_name,
            last_name=user.last_name,
            company_name=user.company_name
        )


@router.put("", response_model=dict)
def update_profile(
    data: ProfileUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Валидация по ролям
    if data.company_name and current_user.role != "employer":
        raise HTTPException(status_code=403, detail="Только работодатель может обновлять название компании")

    if any([
        data.experience_months is not None,
        data.rate_per_shift is not None
    ]) and current_user.role != "worker":
        raise HTTPException(status_code=403, detail="Только работник может обновлять опыт или ставку")

    update_data = data.dict(exclude_unset=True)

    if not update_data:
        return {"status": "ничего не обновлено"}

    for field, value in update_data.items():
        setattr(current_user, field, value)

    db.commit()
    return {"status": "updated"}
