from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class ReviewOut(BaseModel):
    id: int
    booking_id: int
    reviewer_id: int
    target_id: int
    rating: int
    comment: Optional[str]
    created_at: datetime

    class Config:
        orm_mode = True
