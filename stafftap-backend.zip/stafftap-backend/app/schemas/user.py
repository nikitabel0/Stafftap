from pydantic import BaseModel, EmailStr, Field
from typing import Optional, Literal
from datetime import date, datetime
from enum import Enum


class UserRole(str, Enum):
    employer = "employer"
    worker = "worker"


class UserCreate(BaseModel):
    first_name: str = Field(..., min_length=1)
    last_name: str = Field(..., min_length=1)
    phone: str = Field(..., min_length=5)
    birth_date: date
    email: EmailStr
    password: str = Field(..., min_length=6)
    role: UserRole

    # Вводятся при необходимости
    company_name: Optional[str] = None
    experience_months: Optional[int] = None
    rate_per_shift: Optional[float] = None


class UserOut(BaseModel):
    id: int
    telegram_id: Optional[int]
    first_name: str
    last_name: str
    phone: str
    birth_date: date
    email: EmailStr
    role: UserRole

    company_name: Optional[str]
    experience_months: Optional[int]
    rate_per_shift: Optional[float]

    is_verified: bool
    is_blocked: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        orm_mode = True
