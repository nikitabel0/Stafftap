from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth,me,profile, upload
from app.database import Base, engine
app = FastAPI()
from fastapi import FastAPI, Depends
from app.dependencies import get_current_user
from app.models.user import User


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # потом заменить на вебапп адрес
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

Base.metadata.create_all(bind=engine)

app.include_router(profile.router)
app.include_router(upload.router)
app.include_router(auth.router)
app.include_router(me.router)
@app.get("/me")
def get_me(current_user: User = Depends(get_current_user)):
    return current_user